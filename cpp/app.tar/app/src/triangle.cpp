#include <triangle.h>

Triangle::Triangle(complex<double> a, complex<double> b, complex<double> c): A(a), B(b), C(c) {
}

double Triangle::area() const {
    return abs((B - A) * conj(C - A)) / 2.0;
}