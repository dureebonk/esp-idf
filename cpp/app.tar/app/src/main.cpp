#include <iostream>
#include <complex>
#include <vector>
#include <triangle.h>
using namespace std;

int main(int argc, char* argv[]) {
    complex<double> A(0, 0);
    complex<double> B(4, 0);
    complex<double> C(0, 3);

    Triangle triangle(A, B, C);
    cout << "Area of the triangle: " << triangle.area() << endl;

    return 0;
}

