#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <complex>
#include <iostream>

using namespace std;

class Triangle {
public:
    Triangle(complex<double> a, complex<double> b, complex<double> c);
    double area() const;
private:
    complex<double> A, B, C;
};
#endif // TRIANGLE_H